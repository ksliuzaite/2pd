package lt.viko.eif.ksliuzaite.menuweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MenuwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
