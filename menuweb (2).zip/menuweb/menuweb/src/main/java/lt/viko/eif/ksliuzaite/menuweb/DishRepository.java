package lt.viko.eif.ksliuzaite.menuweb;

import jakarta.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
public class DishRepository {
    private static final Map<String, Dish> dishes = new HashMap<>();

    @PostConstruct
    public void initData() {
        Dish pizza = new Dish();
        pizza.setNameofdish("Hawaiian pizza");
        pizza.setPrice(9);
        pizza.setIngredient(Ingredient.MOZZARELLA);
        pizza.setIngredient(Ingredient.CHICKEN_FILLET);
        pizza.setIngredient(Ingredient.PINEAPPLES);
        pizza.setIngredient(Ingredient.TOMATO_SAUCE);
        pizza.setAllergen(Allergen.GLUTEN);
        pizza.setAllergen(Allergen.LACTOSE);


        dishes.put(pizza.getNameofdish(), pizza);

        Dish pork_ribs = new Dish();
        pork_ribs.setNameofdish("Pork ribs with homemade chipotle - mustard sauce");
        pork_ribs.setPrice(12);
        pork_ribs.setIngredient(Ingredient.PORK_RIBS);
        pork_ribs.setIngredient(Ingredient.POTATO_WEDGES);
        pork_ribs.setIngredient(Ingredient.CRISPY_ONION_RINGS);
        pork_ribs.setIngredient(Ingredient.COLESLAW_SALAD);
        pork_ribs.setIngredient(Ingredient.CHIPOTLE_MUSTARD_SAUCE);
        pork_ribs.setAllergen(Allergen.GLUTEN);
        pork_ribs.setAllergen(Allergen.LACTOSE);
        pork_ribs.setAllergen(Allergen.EGGS_AND_THEIR_PRODUCTS);
        pork_ribs.setAllergen(Allergen.MUSTARD_AND_THEIR_PRODUCTS);

        dishes.put(pork_ribs.getNameofdish(), pork_ribs);

    }

    public Dish findDish(String name) {
        Assert.notNull(name, "The dish's name must not be null");
        return dishes.get(name);
    }
}
