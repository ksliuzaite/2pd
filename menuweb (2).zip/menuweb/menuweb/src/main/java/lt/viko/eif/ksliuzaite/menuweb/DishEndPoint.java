package lt.viko.eif.ksliuzaite.menuweb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@Endpoint
public class DishEndPoint {
    private static final String NAMESPACE_URI = "http://www.Restaurant.lt/viko/eif/ksliuzaite/menu_web";

    private DishRepository dishRepository;

    @Autowired
    public DishEndPoint(DishRepository dishRepository) {
        this.dishRepository = dishRepository;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getDishRequest")
    @ResponsePayload
    public GetDishResponse getDish(@RequestPayload GetDishRequest request) {
        GetDishResponse response = new GetDishResponse();
        response.setDish(dishRepository.findDish(request.getNameofdish()));

        return response;
    }
}

