
package lt.viko.eif.ksliuzaite.menuclient;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Dish complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Dish">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="nameofdish" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="price" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ingredient" type="{http://www.Restaurant.lt/viko/eif/ksliuzaite/menu_web}ingredient"/>
 *         &lt;element name="allergen" type="{http://www.Restaurant.lt/viko/eif/ksliuzaite/menu_web}allergen"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Dish", propOrder = {
    "nameofdish",
    "price",
    "ingredient",
    "allergen"
})
public class Dish {

    @XmlElement(required = true)
    protected String nameofdish;
    protected int price;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected Ingredient ingredient;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected Allergen allergen;

    /**
     * Gets the value of the nameofdish property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameofdish() {
        return nameofdish;
    }

    /**
     * Sets the value of the nameofdish property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameofdish(String value) {
        this.nameofdish = value;
    }

    /**
     * Gets the value of the price property.
     * 
     */
    public int getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     */
    public void setPrice(int value) {
        this.price = value;
    }

    /**
     * Gets the value of the ingredient property.
     * 
     * @return
     *     possible object is
     *     {@link Ingredient }
     *     
     */
    public Ingredient getIngredient() {
        return ingredient;
    }

    /**
     * Sets the value of the ingredient property.
     * 
     * @param value
     *     allowed object is
     *     {@link Ingredient }
     *     
     */
    public void setIngredient(Ingredient value) {
        this.ingredient = value;
    }

    /**
     * Gets the value of the allergen property.
     * 
     * @return
     *     possible object is
     *     {@link Allergen }
     *     
     */
    public Allergen getAllergen() {
        return allergen;
    }

    /**
     * Sets the value of the allergen property.
     * 
     * @param value
     *     allowed object is
     *     {@link Allergen }
     *     
     */
    public void setAllergen(Allergen value) {
        this.allergen = value;
    }

}
