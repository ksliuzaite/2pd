
package lt.viko.eif.ksliuzaite.menuclient;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dish" type="{http://www.Restaurant.lt/viko/eif/ksliuzaite/menu_web}Dish"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "dish"
})
@XmlRootElement(name = "getDishResponse")
public class GetDishResponse {

    @XmlElement(required = true)
    protected Dish dish;

    /**
     * Gets the value of the dish property.
     * 
     * @return
     *     possible object is
     *     {@link Dish }
     *     
     */
    public Dish getDish() {
        return dish;
    }

    /**
     * Sets the value of the dish property.
     * 
     * @param value
     *     allowed object is
     *     {@link Dish }
     *     
     */
    public void setDish(Dish value) {
        this.dish = value;
    }

}
