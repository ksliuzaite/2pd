@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://www.Restaurant.lt/viko/eif/ksliuzaite/menu_web", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package lt.viko.eif.ksliuzaite.menuclient;
