package lt.viko.eif.ksliuzaite.menuclient;

public class Main {
    public static void main(String[] args){
        MenuPortService service = new MenuPortService();
        MenuPort port = service.getMenuPortSoap11();
        GetDishRequest request = new GetDishRequest();
        request.setNameofdish("Hawaiian pizza");
        GetDishResponse response = port.getDish(request);

        Dish dish = response.getDish();
        System.out.println(dish.getNameofdish());
        System.out.println(dish.getPrice());
        System.out.println(dish.getIngredient());
        System.out.println(dish.getAllergen());
    }
}