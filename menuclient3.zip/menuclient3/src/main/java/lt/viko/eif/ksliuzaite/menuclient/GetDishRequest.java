
package lt.viko.eif.ksliuzaite.menuclient;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="nameofdish" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "nameofdish"
})
@XmlRootElement(name = "getDishRequest")
public class GetDishRequest {

    @XmlElement(required = true)
    protected String nameofdish;

    /**
     * Gets the value of the nameofdish property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameofdish() {
        return nameofdish;
    }

    /**
     * Sets the value of the nameofdish property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameofdish(String value) {
        this.nameofdish = value;
    }

}
