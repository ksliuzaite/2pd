
package lt.viko.eif.ksliuzaite.menuclient;

import jakarta.xml.bind.annotation.XmlEnum;
import jakarta.xml.bind.annotation.XmlEnumValue;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for allergen.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="allergen">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Gluten"/>
 *     &lt;enumeration value="Lactose"/>
 *     &lt;enumeration value="Mustard_and_their_products"/>
 *     &lt;enumeration value="Eggs_and_their_products"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "allergen")
@XmlEnum
public enum Allergen {

    @XmlEnumValue("Gluten")
    GLUTEN("Gluten"),
    @XmlEnumValue("Lactose")
    LACTOSE("Lactose"),
    @XmlEnumValue("Mustard_and_their_products")
    MUSTARD_AND_THEIR_PRODUCTS("Mustard_and_their_products"),
    @XmlEnumValue("Eggs_and_their_products")
    EGGS_AND_THEIR_PRODUCTS("Eggs_and_their_products");
    private final String value;

    Allergen(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Allergen fromValue(String v) {
        for (Allergen c: Allergen.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
