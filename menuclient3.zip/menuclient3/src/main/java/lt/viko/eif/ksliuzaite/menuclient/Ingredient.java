
package lt.viko.eif.ksliuzaite.menuclient;

import jakarta.xml.bind.annotation.XmlEnum;
import jakarta.xml.bind.annotation.XmlEnumValue;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ingredient.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ingredient">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Mozzarella"/>
 *     &lt;enumeration value="Tomato_sauce"/>
 *     &lt;enumeration value="Pineapples"/>
 *     &lt;enumeration value="Chicken_fillet"/>
 *     &lt;enumeration value="Pork_ribs"/>
 *     &lt;enumeration value="Chipotle_mustard_sauce"/>
 *     &lt;enumeration value="Coleslaw_salad"/>
 *     &lt;enumeration value="Potato_wedges"/>
 *     &lt;enumeration value="Crispy_onion_rings"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ingredient")
@XmlEnum
public enum Ingredient {

    @XmlEnumValue("Mozzarella")
    MOZZARELLA("Mozzarella"),
    @XmlEnumValue("Tomato_sauce")
    TOMATO_SAUCE("Tomato_sauce"),
    @XmlEnumValue("Pineapples")
    PINEAPPLES("Pineapples"),
    @XmlEnumValue("Chicken_fillet")
    CHICKEN_FILLET("Chicken_fillet"),
    @XmlEnumValue("Pork_ribs")
    PORK_RIBS("Pork_ribs"),
    @XmlEnumValue("Chipotle_mustard_sauce")
    CHIPOTLE_MUSTARD_SAUCE("Chipotle_mustard_sauce"),
    @XmlEnumValue("Coleslaw_salad")
    COLESLAW_SALAD("Coleslaw_salad"),
    @XmlEnumValue("Potato_wedges")
    POTATO_WEDGES("Potato_wedges"),
    @XmlEnumValue("Crispy_onion_rings")
    CRISPY_ONION_RINGS("Crispy_onion_rings");
    private final String value;

    Ingredient(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Ingredient fromValue(String v) {
        for (Ingredient c: Ingredient.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
